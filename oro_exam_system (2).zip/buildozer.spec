[app]
title = Oro Exam System
package.name = oroexamsystem
package.domain = org.oro
source.dir = .
source.include_exts = py,png,jpg,kv,json,txt,db,csv
version = 1.0.0
requirements = python3,kivy==2.3.0,sqlite3,reportlab,kivymd
orientation = portrait
android.permissions = INTERNET, WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE
android.api = 33
android.minapi = 21
android.private_storage = True
p4a.bootstrap = sdl2
android.archs = arm64-v8a, armeabi-v7a

[buildozer]
log_level = 2
warn_on_root = 1
